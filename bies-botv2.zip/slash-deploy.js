const { REST, Routes } = require("discord.js")
const botID = "1178075016458403850"
const serverID = "1115963224462999613"
const botToken = process.env.token


const rest = new REST().setToken(botToken)
const slashRegister = async () => {
  try {
    await rest.put(Routes.applicationGuildCommands(botID, serverID),{
      body : [
        {
          name: "ping",
          description : "LOOK A COMMAND"
        },
        {
          name: "pong",
          description : "LOOK A COMMAND (again)"
        },
      ]
    })
  } catch (error) {
    console.error(error)
  }
}
slashRegister();