const express = require("express");
const app = express();
const Database = require("@replit/database")
const db = new Database()
const keep_alive = require('./keep_alive')


app.listen(3000, () => {
  console.log("Lets start the trolling");
})

app.get("/", (req, res) => {
  res.send(`Epic troller is loading...
 How did you find this?`);
})

const Discord = require("discord.js");
const client = new Discord.Client({intents: ["GUILDS", "GUILD_MESSAGES"]});
const { MessageActionRow, MessageButton} = require("discord.js")
const pagination = require("discord.js-pagination")

client.on("ready", () => {
  client.user.setActivity("pizza in the oven",{type: "WATCHING"})
})

client.on('interactionCreate', async interaction => {
  if (!interaction.isButton()) return;
  if (interaction.customId === 'giveRoleButton') {
    const member = interaction.member;
    const role = interaction.guild.roles.cache.find(role => role.name === "Server Pings");
    if (!role) return console.log("Role not found");
    try {
      await member.roles.add(role);
      interaction.reply({ content: 'You now have the Server pings role', ephemeral: true})
      member.guild.channels.cache.get("1185295538720100362").send(`yes1`)
    } catch (error) {
      console.error(error);
    }
  }
  if (interaction.customId === 'giveRoleButton2') {
    const member = interaction.member;
    const role = interaction.guild.roles.cache.find(role => role.name === "TvR Pings");
    if (!role) return console.log("Role not found");
    try {
      await member.roles.add(role);
      interaction.reply({ content: 'You now have the TvR Pings role', ephemeral: true})
      member.guild.channels.cache.get("1185295538720100362").send(`yes2`)
    } catch (error) {
      console.error(error);
    }
  }
  if (interaction.customId === 'clearRoleButton') {
    const member = interaction.member;
    const role = interaction.guild.roles.cache.find(role => role.name === "TvR Pings");
    const role2 = interaction.guild.roles.cache.find(role => role.name === "Server Pings");
    if (!role) return console.log("Role not found");
    if (!role2) return console.log("Role not found");
    try {
      interaction.reply({ content: 'You now have no roles', ephemeral: true})
      await member.roles.remove(role);
      await member.roles.remove(role2);
      member.guild.channels.cache.get("1185295538720100362").send(`delete yes`)
    } catch (error) {
      console.error(error);
    }
  }
});

client.on('messageDelete', async deletedMessage => {
  const channel = deletedMessage.guild.channels.cache.get('1185295538720100362');
  let embed = new Discord.MessageEmbed()
  .setTitle(`${deletedMessage.author.username}'s message is deleted`)
  .setDescription(`${deletedMessage.content}`)
  .setFooter("I'm doing this that no one gets pinged")
  .setColor("RED")
  channel.send( {embeds : [ embed ] } )
});

client.on('messageUpdate', async (oldMessage, newMessage) => {
  const channel = oldMessage.guild.channels.cache.get('1185295538720100362');
  let embed = new Discord.MessageEmbed()
  .setTitle(`${oldMessage.author.username}'s message is edited`)
  .setDescription(`**Used to be: **${oldMessage.content}
  **It's now: **${newMessage.content}`)
  .setFooter("I'm doing this that no one gets pinged")
  .setColor("RED")
  channel.send( {embeds : [ embed ] } )
})

client.on("messageCreate", async message => {
  //secret
  if (message.author.bot) {
  } else {
    const member = message.member
    if (member.roles.cache.has('1115992837775953951')) {
    } else {
      const role = message.guild.roles.cache.find(role => role.name === "Member");
     await member.roles.add(role);
     if (message.channelId==="1185652419976237208") {
        message.react('<:BiesBotAccepted:1185991882543734815>')
        message.react('<:BiesBotDeclined:1186037391534850048>')
      }
    }
  }
  if(message.content.startsWith("hi") || message.content.startsWith("Hi") || message.content.startsWith("hI"))  { 
    if (message.author.bot) {
    } else {
      message.reply("hi")
    }
  }
  if (message.content.match(/https?:\/\/\S+/)) {
    if (message.channelId==="1115970516176621639") {
      if (message.content.startsWith("https://tenor.com/view/")) {
      } else {
        message.delete();
        message.channel.send(`You can not send links here buddy. <@${message.author.id}>`)
      }
    } else if (message.channelId==="1185652419976237208") {
      if (message.content.startsWith("https://tenor.com/view/")) {
      } else {
        message.delete();
        message.channel.send(`You can not send links here buddy. <@${message.author.id}>`)
      }
    }
  }
  if (message.content.match("discord.gg")) {
    if (message.channelId==="1115970516176621639") {
      message.delete();
      message.channel.send(`You can not send invites here buddy. <@${message.author.id}>`)
    } else if (message.channelId==="1185652419976237208") {
      message.delete();
      message.channel.send(`You can not send invites here buddy. <@${message.author.id}>`)
    }
  }
  if (message.content.match("faggot") || message.content.match("FAGGOT")) {
    message.delete();
    message.channel.send(`You can not be harassing people here buddy.`)
  }
  if (message.content.match("CUNT") || message.content.match("cunt")) {
    message.delete();
    message.channel.send(`You can not be harassing people here buddy.`)
  }
})

client.login(process.env.token);